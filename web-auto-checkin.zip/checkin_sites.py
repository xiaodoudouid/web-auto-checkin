import aiohttp
import asyncio
import json
from typing import Dict, Any, Optional, List
from bs4 import BeautifulSoup

class BaseCheckin:
    """签到基类，所有网站签到类都继承自此类"""
    
    def __init__(self, site_config: Dict[str, Any], global_config: Dict[str, Any]):
        self.site_config = site_config
        self.global_config = global_config
        self.session = None
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }
        
    async def init_session(self) -> None:
        """初始化会话"""
        self.session = aiohttp.ClientSession(headers=self.headers)
        
    async def close_session(self) -> None:
        """关闭会话"""
        if self.session:
            await self.session.close()
            
    async def login(self) -> bool:
        """登录方法，子类需要实现"""
        raise NotImplementedError("子类必须实现login方法")
        
    async def checkin(self) -> Dict[str, Any]:
        """签到方法，子类需要实现"""
        raise NotImplementedError("子类必须实现checkin方法")
        
    async def run(self) -> Dict[str, Any]:
        """执行签到流程"""
        try:
            await self.init_session()
            
            # 登录检查
            is_logged_in = await self.login()
            if not is_logged_in:
                return {"success": False, "message": "登录失败"}
                
            # 执行签到
            return await self.checkin()
            
        finally:
            await self.close_session()

class V2exCheckin(BaseCheckin):
    """V2EX签到实现"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.base_url = "https://www.v2ex.com"
        
    async def login(self) -> bool:
        """V2EX登录实现"""
        cookies = self.site_config.get("cookies", {})
        if not cookies:
            return False
            
        # 检查是否登录成功
        async with self.session.get(f"{self.base_url}/mission/daily", cookies=cookies) as response:
            if response.status == 200:
                text = await response.text()
                return "每日登录奖励" in text
        return False
        
    async def checkin(self) -> Dict[str, Any]:
        """V2EX签到实现"""
        cookies = self.site_config.get("cookies", {})
        
        # 获取once参数
        async with self.session.get(f"{self.base_url}/mission/daily", cookies=cookies) as response:
            text = await response.text()
            soup = BeautifulSoup(text, "html.parser")
            once_element = soup.find("input", {"name": "once"})
            if not once_element:
                return {"success": False, "message": "未找到once参数"}
                
            once = once_element.get("value")
            
        # 执行签到
        async with self.session.get(f"{self.base_url}/mission/daily/redeem?once={once}", cookies=cookies) as response:
            text = await response.text()
            if "已经领取过今日登录奖励" in text:
                return {"success": True, "message": "今日已签到"}
            elif "领取到了" in text:
                return {"success": True, "message": "签到成功"}
            else:
                return {"success": False, "message": "签到失败"}

class GitHubCheckin(BaseCheckin):
    """GitHub签到(活动记录)实现"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.base_url = "https://github.com"
        
    async def login(self) -> bool:
        """GitHub登录实现"""
        token = self.site_config.get("token")
        if not token:
            return False
            
        self.headers["Authorization"] = f"token {token}"
        return True
        
    async def checkin(self) -> Dict[str, Any]:
        """GitHub活动记录检查"""
        username = self.site_config.get("username")
        if not username:
            return {"success": False, "message": "缺少用户名配置"}
            
        async with self.session.get(f"{self.base_url}/{username}") as response:
            if response.status == 200:
                text = await response.text()
                # 简单检查是否有活动记录
                if "No contributions" in text:
                    return {"success": True, "message": "今日无活动记录"}
                else:
                    return {"success": True, "message": "已有活动记录"}
            else:
                return {"success": False, "message": f"请求失败: {response.status}"}

# 注册所有支持的签到类
SUPPORTED_SITES = {
    "v2ex": V2exCheckin,
    "github": GitHubCheckin
}

def get_checkin_class(site_type: str) -> Optional[BaseCheckin]:
    """根据站点类型获取对应的签到类"""
    return SUPPORTED_SITES.get(site_type.lower())    