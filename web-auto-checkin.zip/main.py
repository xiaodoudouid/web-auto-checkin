import os
import json
import logging
import asyncio
from datetime import datetime
from typing import Dict, List, Optional, Any
from checkin_sites import get_checkin_class

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("checkin.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("AutoCheckin")

class ConfigManager:
    """配置管理器，负责读取和保存配置"""
    
    def __init__(self, config_path: str = "config.json"):
        self.config_path = config_path
        self.config = self.load_config()
        
    def load_config(self) -> Dict[str, Any]:
        """加载配置文件"""
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            return {"sites": [], "global": {}}
        except Exception as e:
            logger.error(f"加载配置失败: {e}")
            return {"sites": [], "global": {}}
    
    def save_config(self) -> None:
        """保存配置文件"""
        try:
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, ensure_ascii=False, indent=2)
            logger.info("配置已保存")
        except Exception as e:
            logger.error(f"保存配置失败: {e}")

class AutoCheckin:
    """自动签到主类"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.global_config = config.get("global", {})
        self.sites = config.get("sites", [])
        self.results = []
        
    async def run_checkin(self, site_config: Dict[str, Any]) -> Dict[str, Any]:
        """执行单个网站的签到"""
        result = {
            "name": site_config.get("name", "未知站点"),
            "success": False,
            "message": "",
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        try:
            site_type = site_config.get("type")
            if not site_type:
                result["message"] = "缺少站点类型配置"
                return result
                
            # 获取对应的签到类
            checkin_class = get_checkin_class(site_type)
            if not checkin_class:
                result["message"] = f"不支持的站点类型: {site_type}"
                return result
                
            # 初始化并执行签到
            checkin = checkin_class(site_config, self.global_config)
            site_result = await checkin.run()
            
            # 更新结果
            result.update(site_result)
            result["success"] = True
            
        except Exception as e:
            result["message"] = f"签到过程出错: {str(e)}"
            logger.exception(f"站点 {result['name']} 签到异常")
            
        return result
    
    async def run_all_sites(self) -> List[Dict[str, Any]]:
        """执行所有网站的签到"""
        logger.info("开始执行批量签到任务")
        tasks = [self.run_checkin(site) for site in self.sites]
        self.results = await asyncio.gather(*tasks)
        
        # 输出统计结果
        success_count = sum(1 for r in self.results if r.get("success"))
        total_count = len(self.results)
        logger.info(f"签到完成: 成功 {success_count}/{total_count}")
        
        return self.results
    
    def get_summary(self) -> str:
        """获取签到结果摘要"""
        if not self.results:
            return "暂无签到结果"
            
        lines = ["=" * 30, "    自动签到结果汇总    ", "=" * 30]
        for result in self.results:
            status = "✅" if result.get("success") else "❌"
            lines.append(f"{status} {result['name']}: {result.get('message', '无消息')}")
        
        success_count = sum(1 for r in self.results if r.get("success"))
        total_count = len(self.results)
        lines.append("-" * 30)
        lines.append(f"总计: 成功 {success_count}/{total_count}")
        lines.append("=" * 30)
        
        return "\n".join(lines)

async def main():
    """主函数"""
    config_manager = ConfigManager()
    config = config_manager.load_config()
    
    # 检查配置是否存在
    if not config.get("sites"):
        logger.warning("未找到站点配置，请先配置需要签到的网站")
        return
        
    # 执行签到
    checkin = AutoCheckin(config)
    await checkin.run_all_sites()
    
    # 打印摘要
    print(checkin.get_summary())
    
    # TODO: 可以添加通知功能，如发送邮件、微信通知等

if __name__ == "__main__":
    asyncio.run(main())    